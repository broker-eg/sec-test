throw new Error('SEC_TEST_INSTALL_CODE_EXECUTED dependency ' + process.argv[2]);
