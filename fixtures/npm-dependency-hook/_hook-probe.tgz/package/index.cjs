module.exports = { value: 'dependency-installed-without-hooks' };
