require('./record.cjs')(require('node:path').resolve(__dirname, '../..', '_attack-evidence.json'), 'dependency', process.argv[2]);
