module.exports = 'dependency-loaded';
